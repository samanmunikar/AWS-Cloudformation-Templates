def lambda_handler(event, context):
    print("Event triggered me");
    return "Success-Event triggered me"
